<template>
  <component :is="link ? 'a' : 'div'" :href="link" class="feature-card">
    <div class="icon-wrapper" :style="{ background: color || 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)' }">
      <template v-if="typeof icon === 'string'"><span class="emoji-icon">{{ icon }}</span></template>
      <component v-else :is="icon" :size="24" />
    </div>
    <h3 class="title">{{ title }}</h3>
    <p class="description">{{ description }}</p>
  </component>
</template>

<script setup lang="ts">
import type { Component } from 'vue'

defineProps<{
  icon: Component | string
  title: string
  description: string
  color?: string
  link?: string
}>()
</script>

<style scoped>
.feature-card {
  padding: 1.5rem;
  border-radius: 12px;
  border: 1px solid hsl(var(--border) / 0.7);
  background: hsl(var(--card));
  transition: all 0.2s ease;
  text-decoration: none;
  color: inherit;
  display: block;
}

.feature-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
  border-color: color-mix(in srgb, var(--page-accent-1, #6366f1) 30%, transparent);
}

.dark .feature-card:hover {
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
}

.icon-wrapper {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1rem;
  transition: transform 0.2s ease;
}

.feature-card:hover .icon-wrapper {
  transform: scale(1.08);
}

.emoji-icon {
  font-size: 1.25rem;
  line-height: 1;
}

.title {
  font-size: 1.1rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: hsl(var(--foreground));
}

.description {
  font-size: 0.9rem;
  line-height: 1.6;
  color: hsl(var(--muted-foreground));
  margin: 0;
}
</style>
