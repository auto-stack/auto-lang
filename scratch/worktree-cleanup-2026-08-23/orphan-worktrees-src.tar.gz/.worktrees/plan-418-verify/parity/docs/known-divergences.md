# Known Divergences

This file records all accepted and open divergences between AutoVM, a2r, and
native Rust for replicated libraries.

## Format

Each entry has:
- **DIV-NNNN**: unique ID
- **库**: library name
- **用例**: test case name
- **AutoVM 行为**: what AutoVM produces
- **a2r 行为**: what a2r transpiled Rust produces
- **Rust 原生行为**: what native Rust produces
- **偏差类型**: 可接受 / 待修复 / 已修复
- **状态**: accepted / open / fixed
- **原因**: explanation

---

## Current phase status (Plan 348, verified 2026-07)

**2026-08-23 修复记录（DIV-A2R-STRPARAM-1,已翻转 fixed）**:2026-08-22 全量
仪表盘重跑发现的 base64/url/serde_json 三库 a2r 编译级回归(字符串实参
`&str` 借用缺失,`String` 直传 `&str` 形参→E0308)已于当日 Plan 427 根治。
引入提交实证为 **3f6aa1be**(Plan 396 §2.4, 2026-08-21):`is_str_slice_var`
补查 `local_var_types` 的 StrSlice 登记,而该 map 把所有 str 型局部(含产物
Rust 中实为 owned String 的显式 `let x str`)都记为 StrSlice,于是调用点
`.as_str()` 自动借用被整体抑制→E0308。§2.4 的真实目标(&str 返回 scrutinee
的 `Some(x)` is-arm 绑定)改走专属集合 `str_slice_pattern_bindings`。
防线:golden 008_str_param_borrow(产物独立 cargo 编译运行 5/5 +
rustc 类型检查冒烟)。三库恢复 **serde_json 56/56、url 30/30、base64
33/33**;稳定全绿核心集回到 **260 例/10 库**(regex 45、cli_app 32、
string_utils 22、trait_advanced 18、tokio 13、generators 6、
http_client_sync 5 + serde_json 56、url 30、base64 33)+ consumer-mode
3 库(fs/process/text 22 例)。

Open gaps (each detailed in its own section below, fix plans in
`docs/plans/359-auto-as-rust-script-rollout.md` Phase E):

| ID | Area | Status | Blocks |
|----|------|--------|--------|
| DIV-TRAIT-VM-1 | VM: bounded generic functions `<T has Spec>` | ✅ fixed (2026-08-22, Plan 417-E3) | trait_advanced 三方 14/14 |
| DIV-TRAIT-VM-2 | VM: trait checker skips default-body methods | ✅ fixed (2026-08-22, Plan 417-E4) | trait_vm_tests ×2 |
| DIV-TRAIT-LANG-1 | language: spec associated types | ✅ fixed (2026-08-22, Plan 417-E2) | trait_advanced 三方 14/14 |
| DIV-HTTP-LANG-1 | parser: stdlib `auto/http.at` `Type.method` decl | ✅ fixed (verified 2026-08-22, Plan 417-E5) | http_client_sync 三方 5/5 |
| DIV-A2R-CHAR-AT-1 | a2r: `char_at` result inferred as string | ✅ fixed (2026-08-22, Plan 417-E1) | golden 007_char_at_infer |
| DIV-A2R-STRPARAM-1 | a2r: call-site `&str` auto-borrow suppressed | ✅ fixed (2026-08-23, Plan 427) | base64/url/serde_json 三方全绿; golden 008_str_param_borrow |

The entries below are library/tooling limitations that shaped the
implementations but are **not** test-case divergences — every included case
agrees across all three backends.

## url (P1)

All 30 url test cases are consistent across AutoVM, a2r and native Rust
(100%). No test-case-level divergences are accepted.

The following are **library/tooling limitations discovered during the url
replication and worked around in the implementation**, recorded here for
future reference. They are not test-case divergences (every case passes on
all three backends); they shaped the API design.

### VM limitations (AutoVM)

- **DIV-URL-VM-1 — user-defined structs do not reliably cross the module
  boundary.** ~~When a function in one module returns `Ok(Url { ... })` and a
  caller in another module destructures it via `Ok(u)`, the struct value is
  corrupted (field reads return the wrong value). Workaround: the url
  replication returns only `str`/`int` primitives across the module boundary
  (no `Url` record), so each accessor re-slices the raw URL string.~~
  **Fixed in Plan 348 (Bug B1):** a `Url` struct now crosses the module
  boundary through `Result Ok(...)` with all fields readable. The url library
  was rewritten to return `Result[Url, str]` from `parse()`; the test reads
  struct fields (`u.scheme`) directly. The free-function accessors remain as
  thin conveniences but are no longer a workaround.
  - AutoVM: fixed (struct fields readable across boundary)
  - a2r: works (parity runner's `wrap_as_module` now promotes struct fields to
    `pub` so cross-module field reads compile)
  - Rust: n/a
  - 状态: fixed (Plan 348 cleanup)

- **DIV-URL-VM-2 — `Err` string payload of a `Result` is corrupted when read
  via an `is`/`match` binding in the AutoVM.** The bound value comes back as a
  small negative integer (a leaked tag marker) rather than the message
  string. Workaround: error test cases assert *that* parsing failed
  (`is_err`), not the message content (same pattern as base64's `check_err`).
  - AutoVM: Err message unreadable (returns e.g. `-2`)
  - a2r: message reads correctly
  - Rust: message reads correctly
  - 偏差类型: 可接受 (accepted — tests check pass/fail, not message text)
  - 状态: accepted

- **DIV-URL-VM-3 — instance methods on a `type` combined with a static
  `fn new` constructor miscompute field reads** (`[GET_FIELD] non-i32`).
  Workaround: the url replication uses free functions, not type methods.
  - 状态: documented (design avoids the path)

### a2r transpiler (fixed in Plan 347)

- **DIV-URL-A2R-1 — `Result` Ok-type inference assumed `String`** for any
  un-annotated function returning `Ok(...)`, so `Ok(Url { ... })` produced
  `Result<String, String>` and failed to compile. Fixed: the transpiler now
  infers the Ok payload type (struct construction → `Result<Url, String>`;
  string payload → `Result<String, String>` as before). Fixed in
  `crates/auto-lang/src/trans/rust.rs`.
  - 状态: fixed

- **DIV-URL-A2R-2 — `use auto.url: ...` was routed to the non-existent
  `a2r_std::url`** because `url` appeared in the transpiler's hardcoded
  stdlib-module list (although `a2r-std` has no `url` module). This broke
  imports of the replicated `url` library in parity tests. Fixed: `url`
  removed from the stdlib-module lists so the import resolves to
  `crate::url` (the replicated library). Fixed in
  `crates/auto-lang/src/trans/rust.rs`.
  - 状态: fixed

### url crate representation differences (by design)

These are deliberate simplifications of the parser, not bugs. The test suite
is constructed so all three backends agree:

- Optional port/query/fragment use sentinels (`-1` / `""`) instead of
  `Option`; absence is tested separately from presence.
- No default-port stripping (tests use only non-default ports like 8080/8443).
- No percent-decoding or host lower-casing (scheme is lower-cased; hosts in
  tests are already lower-case).

## rusqlite (P3)

All 65 rusqlite test cases are consistent across AutoVM, a2r and native
rusqlite 0.31.0 (100%). No test-case-level divergences are accepted. The
replication covers rusqlite's deterministic query layer — the `FromSql` and
`ToSql` value coercions (type dispatch, integral range checks, Integer->Real /
Integer->bool widening, Blob/Text/Option handling). The native oracle drives
each value through a real in-memory SQLite `SELECT ?1` so the Value->Rust
mapping goes through genuine rusqlite 0.31.0.

The following are **library/tooling limitations discovered during the rusqlite
replication and worked around in the implementation**, recorded here for
future reference. They are not test-case divergences (every included case
passes on all three backends); they shaped the scope and API design.

### Scope limitation: no FFI path for Connection/Statement

- **DIV-RUSQLITE-1 — `use.rust rusqlite::Connection` is not viable in the
  current VM.** `use.rust` `RustFfiBridge` marshals only `VMConvertible`
  primitives (i32, u32, bool, i64, u64, f64, String, Vec<...>, Option, tuples).
  `Connection` and `Statement` are opaque, stateful handles with no
  `VMConvertible` impl and no `RustStdlibObject` shim. Consequently the
  Plan-347 brief's literal "call rusqlite via `use.rust`" path cannot work for
  the connection/query types. The replication instead follows the proven
  parity-library pattern (base64 / url / serde_json / regex / sha2): a pure-Auto
  reimplementation of the deterministic slice, compared three-way against a
  native oracle. SQL execution / query planning is SQLite's job, not
  rusqlite's, and is non-deterministic w.r.t. storage, so it is out of scope.
  - AutoVM: n/a (design avoids the path)
  - a2r: n/a
  - Rust: n/a
  - 偏差类型: 可接受 (accepted — out of scope by design)
  - 状态: documented

### VM limitations (AutoVM), worked around

- **DIV-RUSQLITE-VM-1 — `Result`-wrapped *float* payload corrupts when it
  crosses the module boundary.** A lib function returning `Ok(f)` where `f` is
  `float`, read in another module via an `is`/`match` binding, comes back with
  a mangled bit pattern (`5.0` compares unequal to the literal `5.0`). This is
  the same boundary-corruption family as DIV-URL-VM-1/2, now affecting floats
  in `Result`. Plain (non-`Result`) int / float / str / bool returns cross
  cleanly (bool fixed in Plan 359 / B4 — see the rusqlite cleanup). The parser
  also does not accept the `Result[float, str]` generic syntax that a
  float-returning coercion would need, so the status/value split is still
  load-bearing for the f64/f32 coercions.
  Workaround: each `FromSql` coercion is split into two plain-primitive
  functions — `<name>_status(v) int` (0=Ok, 1=InvalidType, 2=OutOfRange) and
  `<name>_value(v) <T>` — neither of which returns a `Result`. The native
  oracle mirrors this API.
  - AutoVM: float-in-Result corrupted across module boundary
  - a2r: not affected (direct calls, no module boundary)
  - Rust: n/a
  - 偏差类型: 可接受 (accepted — worked around; no test-case divergence)
  - 状态: accepted

- **DIV-RUSQLITE-VM-2 — the 32-bit VM `int` cannot represent i32/u32
  out-of-range boundary values.** The VM `int` is 32-bit signed and silently
  wraps (it has no i64), so the literal `2147483648` (one past `i32::MAX`)
  wraps to `-2147483648`, and `4294967295` (`u32::MAX`) is unrepresentable.
  rusqlite's `FromSql for i32`/`u32` *would* return `OutOfRange` for these, but
  the value cannot be constructed in the VM to test that path. Workaround:
  those specific boundary cases are excluded from the suite; the i32/u32
  in-range and InvalidType paths are covered, and the i8/i16/u8/u16 coercions
  exercise the `OutOfRange` path with values (200, 256, 32768, 65536, -1, ...)
  that ARE representable in a 32-bit int. All three backends agree on every
  included case.
  - AutoVM: cannot construct the out-of-range i32/u32 inputs (32-bit wrap)
  - a2r: same (transpiles the same Auto source; `i32 > i32::MAX` is a
    compile-time-no-op warning)
  - Rust: returns `OutOfRange` correctly (real i64)
  - 偏差类型: 可接受 (accepted — excluded from suite; documented)
  - 状态: accepted

### rusqlite API representation differences (by design)

These are deliberate modelling choices, not bugs. The suite is constructed so
all three backends agree:

- SQLite `Value` is modelled as an opaque `Val { kind, ival, sval, fval }`
  struct (tag + one payload per variant) rather than an enum-with-payload,
  because Auto has no such construct. Callers never read `Val` fields directly.
- `FromSql` error variants are encoded as int status codes (0/1/2) rather than
  the `FromSqlError` enum, because Auto has no enums and the VM corrupts Err
  string payloads (DIV-URL-VM-2).
- `bool` results (`from_bool_value`, `option_is_none`) are returned as plain
  `bool`. (Plan 359 / B4 fixed bool crossing the Auto module boundary, so the
  native oracle and the Auto side now both yield/compare real `bool`s; the
  earlier 0/1-int encoding is no longer needed.)

## Concurrency (Plan 359 Phase 5)

These are language-level limitations of the Auto concurrency model. They are
not test-case divergences; they describe what the runtime supports today.

- **DIV-CONC-1 — `~{ ... }.go` spawn is synchronous-inline (timing).**
  `~{ body }.go` no longer crashes (Plan 359 G1 fixed a stack underflow in the
  `SPAWN_GO` handler and a stray POP in the `Expr::Go` codegen). However, the
  `Expr::AsyncBlock` codegen currently compiles the body **inline** in the
  caller's code stream and passes a placeholder offset (`0`) to `CREATE_FUTURE`.
  As a result the spawned body executes synchronously at the spawn point, and
  `SPAWN_GO` cannot start a real background task (it guards against `body_offset
  == 0` to avoid restarting at address 0). Fire-and-forget programs therefore
  run without crashing, but the spawn does not yet provide true concurrent
  execution. Fixing this requires compiling async-block bodies out-of-line into
  a separate code region and recording the real offset in the Future.

- **DIV-CONC-2 — channels have no Auto-level syntax (language design gap).**
  The VM defines `CHAN_NEW` (0x85), `SEND` (0x86), `RECV` (0x87), and
  `TRY_RECV` (0x88) opcodes with full engine handlers and a Tokio-backed
  `AutoChannel` runtime (`crates/auto-lang/src/vm/channel.rs`), but **no Auto
  surface syntax generates them**. There is no `chan` keyword, no `<-` send/recv
  operator, and no `Channel.new()`/`.send()`/`.recv()` builtin that the parser
  or codegen recognizes. Adding channels is therefore a language-design task
  (deciding syntax + semantics), not a bug fix. Until such syntax exists,
  channel programs cannot be written in Auto source; the opcodes are only
  reachable by hand-assembled ABT. This is tracked as a known limitation.



## trait_advanced (Plan 359 D2)

Three-way parity library `parity/libs/trait_advanced/` is **L1 100% (10/10)**
on its baseline subset: a non-generic spec with required methods, void
default methods, and a non-generic `Comparable` spec with concrete
implementations. The library also probes advanced trait features; the
current status of each:

- **DIV-TRAIT-A2R-1 — value-returning spec default method (FIXED).**
  Previously a2r wrapped the default body as `{ expr; }` -> unit, failing
  E0308. Fixed in Plan 359: `spec_decl` now delegates `Expr::Block` default
  bodies to the generic `body()` emitter, which keeps the tail expression.
  Verified by `crates/auto-lang/test/a2r/12_specs/004_default_body`.
  - 状态: fixed.

- **DIV-TRAIT-A2R-2 — generic spec implementation drops concrete type args
  (FIXED).** `type ScoreCmp as Comparable<i32>` previously transpiled to
  `impl Comparable for ScoreCmp` (missing `<i32>`), failing E0107. Fixed in
  Plan 359: the spec-impl generator now indexes `type_decl.spec_impls` by
  spec_name and emits the concrete `type_args` (`impl Comparable<i32> for
  ScoreCmp`), falling back to declared generic params for non-concrete
  impls (`as Storage<T>`). Verified by `12_specs/005_generic_impl` (rustc
  clean) and zero regression on 13 golden tests (incl. 002_list_storage,
  the boundary case).
  - 2026-08-22 收尾补全 (Plan 417-followup): a2r 修复时留下两半缺口——
    ①VM trait_checker 不把位置式 type_args 替换进 spec 签名比对 (实现者
    `compare(other int) int` 对 spec `compare(other T) T` 误报返回类型不
    符);②a2r 的 trait 声明发射里方法返回位引用 spec 泛型参数时仍中
    PascalCase trait 启发式误发 `-> impl T` (E0404)。修复:checker 的替换
    表并入位置式 type_args (独立于关联类型名校验门);rust.rs 发射 spec
    trait 方法签名时以 spec 自身泛型参数充当 current_fn_type_params。
    新增 golden `12_specs/013_generic_spec_typed_impl` (T 同时出现在参数
    与返回位,VM 与 a2r 独立编译均输出 6)。
  - 状态: fixed (全量)。

- **DIV-TRAIT-A2R-3 — (not a bug; retracted).** An earlier draft recorded a
  "spec method bodies miss `self.` prefix" gap, but investigation showed
  Auto uses a leading-dot self convention inside method bodies (`.field` →
  `self.field`, `.method()` → `self.method()`), which a2r already handles
  correctly (see `12_specs/005_generic_impl`: `.score` → `self.score`). The
  original report used bare `score` in the test source, which is not valid
  Auto for self-field access. No fix needed.

- **DIV-TRAIT-VM-1 — bounded-generic functions (❤✅ fixed 2026-08-22, Plan
  417-E3).** 双断点修复:①语法——`parse_generic_param` 新增 `T has Spec`
  (多 bound `has A + B`) 分支写入既有 `TypeParam.constraint`(与
  `#[with(T as A + B)]` 同字段);`fn_decl_stmt`(无注解路径)补上与注解路
  径一致的 generic_params→type_params 传递(此前 `<T>` 声明在该路径被丢弃,连
  带 a2r 丢 `<T>` 发射);②分派——codegen 新增 `current_fn_type_params`
  追踪,接收者静态类型为当前 fn 泛型参数时方法调用改发 CALL_SPEC(
  运行时按堆对象 tag 拼 `<真实类型>.<方法>` 查 exports)。修复过程中
  探明并修复两个隐藏 bug:a) CALL_SPEC 分派到 VM 函数时未压 CallFrame,
  被调 RET 弹错调用者帧 → `current_fn_n_args` 污染 → LOAD_LOCAL
  参数寻址落入 null 保护(同表达式第二个 CALL_SPEC 必现);际
  有 `is_spec_dispatch` 用户同样受益;b) 链接期字符串池合并的
  `remap_string_indices` 步行器把 CALL_SPEC 按 4 字节跳过(实际 3) 且不重映
  射 method idx → 跨模块 CALL_SPEC 分派错误方法名(一并修正
  disasm 解码表与 opcode 注释)。a2r 侧:`<T: Spec>` 经 parser 贯通自动
  发射;`rust_return_type_name`/`rust_type_name` 的 User 分支对当前 fn 泛型
  参数名直接返回裕名(此前 `-> impl T` 误发射)。验证:
  trait_vm_tests +3(单实现者/多实现者/裸 `<T>`);a2r golden
  08_generics/008_bounded_generic_fn 新增(345/345);parity trait_advanced
  升级 sub-scenario C(bounded_generics.at 4 例,含反向 compare 第二实现者
  证明按接收者类型分派)三方 14/14。调用点界校验已于同日补齐(417-E3-P4:保守式编译期拒绝,参 KNOWN-DEBT 翻转条)。
  状态: ❤✅ fixed。

- **DIV-TRAIT-VM-2 — VM trait checker requires re-declaration of default
  methods (✅ fixed 2026-08-22, Plan 417-E4).** 双端修复:①trait_checker 的
  None 臂跳过带默认体的方法(继承合法);②VM codegen 在 TypeDecl 编译臂
  为未重声明的默认方法合成 `Type.method`(经共享 TypeStore 查询 spec,
  顺序无关;脚本路径 TypeDecl 先编译由 execute_autovm 预注册兜底)。
  实现者重声明=覆盖,语义正确(trait_vm_tests:继承/覆盖/抽象仍强制三态)。
  a2r 侧本就正确(spec→Rust trait 默认方法,天然继承)。库内 workaround
  重声明保留(等价于显式覆盖)。状态: ✅ fixed。

- **DIV-TRAIT-LANG-1 — associated types not supported (✅ fixed 2026-08-22,
  Plan 417-E2).** 四层落地:①parser/AST——SpecDecl.associated_types(`type
  Item` 成员,名字入 current_type_params 使签名引用解析为裸 Type::User)+
  SpecImpl.assoc_bindings(实现处命名式绑定 `as Container<Item=int>`,peek
  `=` 与位置式 type_args 区分);②trait_checker——check_conformance 按绑定
  Type::substitute 替换签名后再比对,未绑定/未知绑定名显式报错;③VM——
  关联类型无运行时实体,TypeDecl 编译臂对声明方法与 E4 合成的默认方法
  均做编译期替换;④a2r——trait 发射 `type Item;`+签名引用重写 `Self::Item`
  (嵌套位置同覆盖),impl 块首发射 `type Item = i64;`,rust_return_type_name
  豁免 Self:: 前缀的 impl-trait 误加。golden 12_specs/011_associated_types
  (产物独立编译输出 8/7),trait_advanced sub-scenario B L3→L1(三方 14/14)。

## http_client_sync (Plan 359 D3) — ✅ UNBLOCKED (2026-08-22, Plan 417-E5)

Three-way parity now runs **5/5 green** (AutoVM / a2r / native Rust oracle,
double-verified stable; first-run single Rust-oracle failure was a cold
compile + mock-server startup race, not reproducible). The original block
was recorded as:

A partial `parity/libs/http_client_sync/` skeleton exists (mock-server crate
+ Auto wrapper + Rust oracle), but it **cannot run three-way** because of a
pre-existing parser bug:

- **DIV-HTTP-LANG-1 — the shipped stdlib `auto/http.at` does not parse
  (✅ fixed, verified 2026-08-22 / Plan 417-E5).** `stdlib/auto/http.at:51`
  `pub fn Request.method(self Request) str;` — a `Type.method` declaration
  with a trailing `;` — now parses on master (fixed by a later parser batch
  after this divergence was logged; the recorded symptom predates it). The
  mock-server setup/teardown hook the skeleton needed is also in place
  (the parity runner auto-spawns `mock-server/`).
  - AutoVM: `use auto.http` usable; http_client_sync VM backend passes.
  - a2r: transpiles + runs; backend passes.
  - Rust: native oracle passes.
  - 偏差类型: 已修复(登记性翻转——文档滞后于代码的又一例,审计模式重演)。
  - 状态: ✅ fixed;http_client_sync 三方 5/5(2026-08-22 双复跑稳定;首跑
    单败为 oracle 冷编译 + mock-server 启动竞态,不可复现)。

The library now counts toward L1.

## string_utils (Plan 359 D4) — a2r transpiler bug worked around

The library is **L1 100% (22/22)** three-way consistent, but a transpiler
bug is worked around in-source:

- **DIV-A2R-CHAR-AT-1 — `char_at` result + int literal is transpiled as
  string concatenation (open, a2r).** When a variable holds `s.char_at(i)`
  without an explicit `int` type annotation, a2r infers it as a string, so
  `c = c + 32` (intended integer add) becomes `c = format!("{}{}", c, 32)`
  (Rust `String`), causing E0308 ("expected i32, found String"). Workaround:
  declare the variable with an explicit `int` type — `var c int = s.char_at(i)`
  — which makes a2r emit `let mut c: i32 = ... as i32;` and `c = c + 32;`
  correctly. All four `char_at`-bound variables in string_utils.at use this
  annotation.
  - AutoVM: runs correctly (VM types `char_at` as int natively).
  - a2r: without the annotation, emits `format!` concatenation (compile fail);
    with `var c int`, emits correct integer add.
  - Rust: native integer arithmetic.
  - 偏差类型: 已修复 (2026-08-22, Plan 417-E1): `infer_type_from_expr` 把
    `char_at` 从 String 返回方法表移到 Int 臂——未标注的
    `c = s.char_at(i); c = c + 32` 现在发射整数加法（golden
    `04_strings/007_char_at_infer`），string_utils 的四处 `var c int`
    workaround 注解已移除。
  - 状态: ✅ fixed (Plan 417-E1; 推断修复由 golden 007_char_at_infer 验证)。
    三方重跑已恢复:string_utils 22/22 全绿(2026-08-22,417-D2 的
    register_import_signatures 根治了导入函数签名盲区——见 KNOWN-DEBT)。

## Python Parity Divergences

### DIV-PY-FLOAT-1: Python float return values are stringified

- **库**: py_math, py_random, py_struct
- **状态**: open
- **原因**: `py_ffi.rs:666-682` stores floats as strings in the string pool (codegen allocates 1 slot, f64 needs 2). All float tests use `.to(int)` or exact string comparison as workaround.

### DIV-PY-EXCEPT-1: Python exceptions not catchable in Auto

- **库**: all py_* libraries
- **状态**: open (language limitation)
- **原因**: Python exceptions propagate as `FFI("Python call ... failed: ValueError: ...")` VM errors. There is no Auto-side try/catch mechanism for PyFFI errors. A Python exception crashes the AutoVM task.

### DIV-PY-ITER-1: Manual iteration works but no for-loop over Python iterables

- **库**: py_list
- **状态**: open (language limitation)
- **原因**: `py_call(lst, "__iter__")` + `py_call(iter, "__next__")` works for manual iteration. But Auto's `for x in py_list` does not work because Python lists are opaque handles, not Auto-native iterables.

### DIV-PY-KWARGS-1: No keyword argument syntax

- **库**: py_datetime, py_random
- **状态**: open (language limitation)
- **原因**: Auto has no `func(key=value)` syntax. All Python calls must use positional arguments. `timedelta(days=30)` → use `timedelta(30)` instead.

### DIV-PY-AUTOLIST-1: Auto list literals don't marshal to Python list

- **库**: py_random
- **状态**: open
- **原因**: `[1, 2, 3]` in Auto is a VM-internal list, not a Python list. `choice([1,2,3])` fails. Workaround: use Python functions that return lists (sorted, list), or pass strings as iterables.
