#pragma once

struct File {
    char* path;
};

File File_Open(struct File *self, str);
str File_ReadText(struct File *self);
str File_ReadLine(struct File *self);
int File_ReadChar(struct File *self);
int File_ReadBuf(struct File *self, str, int);
void File_WriteLine(struct File *self, str);
void File_Flush(struct File *self);
void File_Close(struct File *self);
void say(char* msg);
